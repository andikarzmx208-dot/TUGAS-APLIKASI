CREATE DATABASE IF NOT EXISTS warung_citut CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE warung_citut;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NULL,
  address TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT NULL,
  price INT UNSIGNED NOT NULL,
  image_url TEXT NULL,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  order_code VARCHAR(40) NOT NULL UNIQUE,
  total INT UNSIGNED NOT NULL,
  address TEXT NOT NULL,
  payment_method ENUM('COD','TRANSFER','EWALLET') NOT NULL DEFAULT 'COD',
  status ENUM('Menunggu','Diproses','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Menunggu',
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  product_id BIGINT UNSIGNED NULL,
  product_name VARCHAR(120) NOT NULL,
  price INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  subtotal INT UNSIGNED NOT NULL,
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS favorites (
  user_id BIGINT UNSIGNED NOT NULL,
  product_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, product_id),
  CONSTRAINT fk_fav_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_fav_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO products (name, category, description, price, image_url) VALUES
('Nasi Goreng','Makanan','Nasi goreng gurih dengan telur dan sayuran.',15000,'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=700'),
('Mie Goreng','Makanan','Mie goreng dengan bumbu khas Warung CiTUT.',12000,'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=700'),
('Ayam Crispy','Makanan','Ayam crispy renyah dengan nasi hangat.',18000,'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=700'),
('Bakso','Makanan','Bakso kuah hangat dengan pelengkap.',12000,'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=700'),
('Es Teh Manis','Minuman','Es teh manis segar untuk menemani makan.',5000,'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=700'),
('Es Jeruk','Minuman','Minuman jeruk segar dan dingin.',7000,'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=700');
