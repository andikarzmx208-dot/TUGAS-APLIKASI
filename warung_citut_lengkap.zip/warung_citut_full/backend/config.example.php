<?php
// Salin menjadi config.php, lalu sesuaikan dengan konfigurasi server MySQL.
return [
  'db_host' => '127.0.0.1',
  'db_name' => 'warung_citut',
  'db_user' => 'root',
  'db_pass' => '',
  // Ganti dengan rahasia acak panjang sebelum dipakai online.
  'token_secret' => 'GANTI_DENGAN_SECRET_ACAK_MINIMAL_32_KARAKTER'
];
