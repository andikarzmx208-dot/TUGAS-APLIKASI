# Waroeng CiTUT — Project Flutter + PHP + MySQL

Project berisi aplikasi Flutter awal, backend REST API PHP, dan skema database MySQL.

## Struktur
- `flutter/` — source aplikasi Flutter yang sudah ada.
- `backend/api.php` — API untuk produk, registrasi/login, profil, pesanan, dan favorit.
- `backend/config.example.php` — contoh konfigurasi koneksi; salin menjadi `config.php`.
- `database/warung_citut.sql` — tabel dan contoh data produk.

## Menyiapkan database/backend
1. Jalankan XAMPP (Apache dan MySQL).
2. Buka phpMyAdmin dan import `database/warung_citut.sql`.
3. Salin `backend/config.example.php` menjadi `backend/config.php`.
4. Sesuaikan host, nama database, user, password, dan `token_secret`.
5. Salin folder `backend` ke `htdocs/warung_citut_api/`.
6. Tes `http://localhost/warung_citut_api/api.php?action=products`.

Endpoint API menerima JSON. Contoh login:
`POST /api.php?action=login` dengan `{"email":"user@example.com","password":"password123"}`.
Untuk endpoint yang butuh login, kirim header `Authorization: Bearer TOKEN`.

## Menjalankan Flutter
1. Buka folder `flutter/` di VS Code.
2. Pastikan Flutter SDK dan Android toolchain terpasang.
3. Jalankan `flutter pub get`, lalu `flutter run`.

## Catatan penting
- Source Flutter di folder ini adalah UI aplikasi yang tersedia sebelumnya. Backend PHP/MySQL disediakan lengkap sebagai API, tetapi source UI belum diintegrasikan untuk memanggil endpoint API secara otomatis. Jadi jangan menganggap login/pesanan di UI sudah tersinkron ke database sampai integrasi API dilakukan.
- Untuk emulator Android, alamat server lokal biasanya `http://10.0.2.2/warung_citut_api/api.php`; untuk perangkat fisik gunakan IP LAN komputer dan pastikan satu jaringan.
- API ini starter project. Sebelum dipublikasikan, gunakan HTTPS, batasi CORS, ganti secret, tambahkan rate limiting, dan lakukan pengujian keamanan.
