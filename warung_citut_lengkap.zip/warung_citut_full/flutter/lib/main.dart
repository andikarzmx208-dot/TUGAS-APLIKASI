import 'package:flutter/material.dart';

void main() {
  runApp(const WarungCitutApp());
}

const Color orange = Color(0xFFE87500);
const Color darkBrown = Color(0xFF5A2C16);
const Color cream = Color(0xFFFFF5DF);
const Color lightCream = Color(0xFFFFEBC5);

class FoodItem {
  final String name;
  final String category;
  final int price;
  final String image;
  final String description;

  const FoodItem({
    required this.name,
    required this.category,
    required this.price,
    required this.image,
    required this.description,
  });
}

const foods = <FoodItem>[
  FoodItem(
    name: 'Nasi Goreng',
    category: 'Makanan',
    price: 15000,
    image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=700',
    description: 'Nasi goreng gurih dengan telur dan sayuran.',
  ),
  FoodItem(
    name: 'Mie Goreng',
    category: 'Makanan',
    price: 12000,
    image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=700',
    description: 'Mie goreng dengan bumbu khas Warung CiTUT.',
  ),
  FoodItem(
    name: 'Ayam Crispy',
    category: 'Makanan',
    price: 18000,
    image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=700',
    description: 'Ayam crispy renyah dengan nasi hangat.',
  ),
  FoodItem(
    name: 'Bakso',
    category: 'Makanan',
    price: 12000,
    image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=700',
    description: 'Bakso kuah hangat dengan pelengkap.',
  ),
  FoodItem(
    name: 'Es Teh Manis',
    category: 'Minuman',
    price: 5000,
    image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=700',
    description: 'Es teh manis segar untuk menemani makan.',
  ),
  FoodItem(
    name: 'Es Jeruk',
    category: 'Minuman',
    price: 7000,
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=700',
    description: 'Minuman jeruk segar dan dingin.',
  ),
];

class CartLine {
  final FoodItem item;
  int qty;
  CartLine(this.item, this.qty);
}

class WarungCitutApp extends StatefulWidget {
  const WarungCitutApp({super.key});

  @override
  State<WarungCitutApp> createState() => _WarungCitutAppState();
}

class _WarungCitutAppState extends State<WarungCitutApp> {
  int tab = 0;
  bool loggedIn = false;
  String username = 'Ghanendra';
  final List<CartLine> cart = [];
  final List<String> orders = [];

  void addToCart(FoodItem item) {
    setState(() {
      final index = cart.indexWhere((e) => e.item.name == item.name);
      if (index >= 0) {
        cart[index].qty++;
      } else {
        cart.add(CartLine(item, 1));
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${item.name} ditambahkan ke keranjang'),
        backgroundColor: orange,
        duration: const Duration(milliseconds: 900),
      ),
    );
  }

  int get cartCount => cart.fold(0, (sum, e) => sum + e.qty);

  int get cartTotal => cart.fold(0, (sum, e) => sum + e.item.price * e.qty);

  void openFood(FoodItem item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FoodDetailPage(item: item, onAdd: () => addToCart(item)),
      ),
    );
  }

  void checkout() {
    if (cart.isEmpty) return;
    setState(() {
      orders.add('Pesanan #${orders.length + 1} • Rp ${money(cartTotal)}');
      cart.clear();
    });
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Pesanan berhasil dibuat!'),
        backgroundColor: orange,
      ),
    );
  }

  void logout() {
    setState(() {
      loggedIn = false;
      username = 'Ghanendra';
      tab = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        foods: foods,
        onOpen: openFood,
        onAdd: addToCart,
        onSearch: () => setState(() => tab = 1),
      ),
      MenuPage(foods: foods, onOpen: openFood, onAdd: addToCart),
      OrdersPage(orders: orders),
      NotificationsPage(),
      ProfilePage(
        loggedIn: loggedIn,
        username: username,
        orderCount: orders.length,
        cartCount: cartCount,
        onLogin: () async {
          final result = await Navigator.push<String>(
            context,
            MaterialPageRoute(builder: (_) => const LoginPage()),
          );
          if (result != null && mounted) {
            setState(() {
              loggedIn = true;
              username = result;
            });
          }
        },
        onLogout: logout,
      ),
    ];

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Warung CiTUT',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
        colorScheme: ColorScheme.fromSeed(seedColor: orange, surface: Colors.white),
        cardTheme: CardThemeData(color: Colors.white, elevation: 1, shadowColor: const Color(0x14000000), margin: const EdgeInsets.symmetric(vertical: 6), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE7E7E7))), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFE7E7E7))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: orange, width: 1.5))),
        appBarTheme: const AppBarTheme(
          backgroundColor: orange,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: Scaffold(
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (value) => setState(() => tab = value),
          backgroundColor: Colors.white,
          indicatorColor: lightCream,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
            NavigationDestination(icon: Icon(Icons.restaurant_menu_outlined), selectedIcon: Icon(Icons.restaurant_menu), label: 'Menu'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Pesanan'),
            NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Notifikasi'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Pengguna'),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: orange,
          foregroundColor: Colors.white,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CartPage(
                cart: cart,
                total: cartTotal,
                onCheckout: checkout,
                onChanged: () => setState(() {}),
              ),
            ),
          ),
          child: Badge(
            isLabelVisible: cartCount > 0,
            label: Text('$cartCount'),
            child: const Icon(Icons.shopping_bag_outlined),
          ),
        ),
      ),
    );
  }
}

String money(int value) {
  final s = value.toString();
  final parts = <String>[];
  for (int i = s.length; i > 0; i -= 3) {
    final start = i - 3 < 0 ? 0 : i - 3;
    parts.insert(0, s.substring(start, i));
  }
  return parts.join('.');
}

class AppHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback? onNotification;

  const AppHeader({
    super.key,
    required this.title,
    required this.subtitle,
    this.onNotification,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 18),
      decoration: const BoxDecoration(
        color: orange,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
            child: const Center(
              child: Text(
                'C\nT',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: orange,
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                  height: .8,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          IconButton(
            onPressed: onNotification,
            icon: const Icon(Icons.notifications_none, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<FoodItem> foods;
  final void Function(FoodItem) onOpen;
  final void Function(FoodItem) onAdd;
  final VoidCallback onSearch;

  const HomePage({
    super.key,
    required this.foods,
    required this.onOpen,
    required this.onAdd,
    required this.onSearch,
  });

  @override
  Widget build(BuildContext context) {
    final popular = foods.take(4).toList();

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        AppHeader(
          title: 'Waroeng CiTUT',
          subtitle: 'Makan Enak, Harga Bersahabat',
          onNotification: () => onSearch(),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
          child: GestureDetector(
            onTap: onSearch,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: const [BoxShadow(color: Color(0x15000000), blurRadius: 8)],
              ),
              child: const Row(
                children: [
                  Icon(Icons.search, color: orange),
                  SizedBox(width: 10),
                  Text('Cari menu, minuman, dll...', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 78,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            scrollDirection: Axis.horizontal,
            children: const [
              CategoryCircle(icon: Icons.lunch_dining, label: 'Makanan'),
              CategoryCircle(icon: Icons.local_drink, label: 'Minuman'),
              CategoryCircle(icon: Icons.star, label: 'Favorit'),
              CategoryCircle(icon: Icons.menu_book, label: 'Semua Menu'),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(18),
          child: Container(
            height: 150,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFF58A19), Color(0xFFD85800)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Stack(
              children: [
                const Positioned(
                  left: 18,
                  top: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Spesial Hari Ini', style: TextStyle(color: Colors.white70)),
                      SizedBox(height: 4),
                      Text('Nasi Ayam Crispy', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                      SizedBox(height: 4),
                      Text('Rasa Juara, Harga Bersahabat', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
                Positioned(
                  right: 12,
                  bottom: 0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.network(
                      foods[2].image,
                      width: 155,
                      height: 125,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.fastfood, size: 80, color: Colors.white70),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            children: [
              const Text('Menu Populer', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: darkBrown)),
              const Spacer(),
              TextButton(onPressed: onSearch, child: const Text('Lihat Semua')),
            ],
          ),
        ),
        SizedBox(
          height: 225,
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            scrollDirection: Axis.horizontal,
            itemCount: popular.length,
            itemBuilder: (_, i) => FoodCard(
              item: popular[i],
              onTap: () => onOpen(popular[i]),
              onAdd: () => onAdd(popular[i]),
              width: 165,
            ),
          ),
        ),
        const SizedBox(height: 90),
      ],
    );
  }
}

class CategoryCircle extends StatelessWidget {
  final IconData icon;
  final String label;
  const CategoryCircle({super.key, required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 86,
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: const BoxDecoration(color: orange, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(height: 5),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class MenuPage extends StatefulWidget {
  final List<FoodItem> foods;
  final void Function(FoodItem) onOpen;
  final void Function(FoodItem) onAdd;

  const MenuPage({super.key, required this.foods, required this.onOpen, required this.onAdd});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  String query = '';
  String category = 'Semua';

  @override
  Widget build(BuildContext context) {
    final result = widget.foods.where((food) {
      final q = food.name.toLowerCase().contains(query.toLowerCase());
      final c = category == 'Semua' || food.category == category;
      return q && c;
    }).toList();

    return Column(
      children: [
        Container(
          color: orange,
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Menu', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(
                onChanged: (v) => setState(() => query = v),
                decoration: InputDecoration(
                  hintText: 'Cari menu...',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            children: ['Semua', 'Makanan', 'Minuman'].map((c) {
              final selected = category == c;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(c),
                  selected: selected,
                  selectedColor: orange,
                  labelStyle: TextStyle(color: selected ? Colors.white : darkBrown, fontWeight: FontWeight.bold),
                  onSelected: (_) => setState(() => category = c),
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: result.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.search_off, size: 54, color: Colors.black26), SizedBox(height: 10), Text('Menu tidak ditemukan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)), SizedBox(height: 4), Text('Coba kata kunci atau kategori lain.', style: TextStyle(color: Colors.black54))])))
              : GridView.builder(
                  padding: const EdgeInsets.all(18),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: .72,
                  ),
                  itemCount: result.length,
                  itemBuilder: (_, i) => FoodCard(
                    item: result[i],
                    onTap: () => widget.onOpen(result[i]),
                    onAdd: () => widget.onAdd(result[i]),
                  ),
                ),
        ),
      ],
    );
  }
}

class FoodCard extends StatelessWidget {
  final FoodItem item;
  final VoidCallback onTap;
  final VoidCallback onAdd;
  final double? width;

  const FoodCard({super.key, required this.item, required this.onTap, required this.onAdd, this.width});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Card(
        elevation: 0,
        color: Colors.white,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Image.network(
                  item.image,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: lightCream,
                    child: const Center(child: Icon(Icons.fastfood, size: 55, color: orange)),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, color: darkBrown)),
                          const SizedBox(height: 3),
                          Text('Rp ${money(item.price)}', style: const TextStyle(color: orange, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: onAdd,
                      icon: const Icon(Icons.add_circle, color: orange),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FoodDetailPage extends StatelessWidget {
  final FoodItem item;
  final VoidCallback onAdd;
  const FoodDetailPage({super.key, required this.item, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(title: Text(item.name)),
      body: Column(
        children: [
          Image.network(
            item.image,
            height: 280,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(height: 280, color: lightCream, child: const Icon(Icons.fastfood, size: 100, color: orange)),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: darkBrown)),
                  const SizedBox(height: 8),
                  Text('Rp ${money(item.price)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: orange)),
                  const SizedBox(height: 18),
                  const Text('Deskripsi', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(item.description, style: const TextStyle(height: 1.5, color: Colors.black54)),
                  const Spacer(),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(16)),
                      onPressed: () {
                        onAdd();
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.shopping_bag_outlined),
                      label: const Text('Tambah ke Keranjang'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class OrdersPage extends StatelessWidget {
  final List<String> orders;
  const OrdersPage({super.key, required this.orders});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const AppHeader(title: 'Pesanan', subtitle: 'Riwayat dan status pesanan'),
        Expanded(
          child: orders.isEmpty
              ? const Center(child: Text('Belum ada pesanan.', style: TextStyle(color: Colors.black54)))
              : ListView.builder(
                  padding: const EdgeInsets.all(18),
                  itemCount: orders.length,
                  itemBuilder: (_, i) => Card(
                    child: ListTile(
                      leading: const CircleAvatar(backgroundColor: lightCream, child: Icon(Icons.receipt_long, color: orange)),
                      title: Text(orders[i]),
                      subtitle: const Text('Pesanan berhasil dibuat'),
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  ),
                ),
        ),
      ],
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const AppHeader(title: 'Notifikasi', subtitle: 'Info terbaru untuk kamu'),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: const [
              NotificationTile(icon: Icons.local_offer, title: 'Promo hari ini', text: 'Ada menu spesial dengan harga bersahabat.'),
              NotificationTile(icon: Icons.check_circle, title: 'Selamat datang', text: 'Terima kasih sudah menggunakan Warung CiTUT.'),
              NotificationTile(icon: Icons.info_outline, title: 'Info aplikasi', text: 'Jangan lupa cek menu terbaru kami.'),
            ],
          ),
        ),
      ],
    );
  }
}

class NotificationTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const NotificationTile({super.key, required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: lightCream, child: Icon(Icons.notifications, color: orange)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(text),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final bool loggedIn;
  final String username;
  final int orderCount;
  final int cartCount;
  final VoidCallback onLogin;
  final VoidCallback onLogout;

  const ProfilePage({
    super.key,
    required this.loggedIn,
    required this.username,
    required this.orderCount,
    required this.cartCount,
    required this.onLogin,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        Container(
          color: orange,
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
          child: Row(
            children: [
              const CircleAvatar(
                radius: 34,
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 45, color: orange),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(loggedIn ? username : 'Tamu', style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
                    Text(loggedIn ? 'user123@gmail.com' : 'Silakan login untuk mengelola akun', style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              const Icon(Icons.settings_outlined, color: Colors.white),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(18),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 18),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                StatItem(label: 'Pesanan', value: '$orderCount'),
                StatItem(label: 'Favorit', value: '3'),
                StatItem(label: 'Keranjang', value: '$cartCount'),
              ],
            ),
          ),
        ),
        const ProfileMenu(icon: Icons.receipt_long, title: 'Riwayat Pesanan', subtitle: 'Lihat pesanan yang pernah dibuat'),
        const ProfileMenu(icon: Icons.location_on_outlined, title: 'Alamat Saya', subtitle: 'Kelola alamat pengiriman'),
        const ProfileMenu(icon: Icons.credit_card, title: 'Metode Pembayaran', subtitle: 'Atur metode pembayaran'),
        const ProfileMenu(icon: Icons.notifications_none, title: 'Notifikasi', subtitle: 'Pengaturan notifikasi aplikasi'),
        const ProfileMenu(icon: Icons.help_outline, title: 'Bantuan & FAQ', subtitle: 'Pertanyaan yang sering diajukan'),
        const ProfileMenu(icon: Icons.info_outline, title: 'Tentang Aplikasi', subtitle: 'Versi aplikasi dan informasi lainnya'),
        Padding(
          padding: const EdgeInsets.all(18),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(15)),
              onPressed: loggedIn ? onLogout : onLogin,
              icon: Icon(loggedIn ? Icons.logout : Icons.login),
              label: Text(loggedIn ? 'Logout' : 'Login'),
            ),
          ),
        ),
        const SizedBox(height: 70),
      ],
    );
  }
}

class StatItem extends StatelessWidget {
  final String label;
  final String value;
  const StatItem({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: darkBrown)),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: Colors.black54)),
      ],
    );
  }
}

class ProfileMenu extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const ProfileMenu({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: darkBrown),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final name = TextEditingController(text: 'Ghanendra');
  final email = TextEditingController(text: 'user123@gmail.com');
  final password = TextEditingController(text: '123456');
  bool obscure = true;
  String? errorMessage;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(title: const Text('Login')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Card(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const CircleAvatar(radius: 40, backgroundColor: lightCream, child: Icon(Icons.storefront, size: 45, color: orange)),
                  const SizedBox(height: 16),
                  const Text('Masuk ke Warung CiTUT', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: darkBrown)),
                  const SizedBox(height: 20),
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama', prefixIcon: Icon(Icons.person))),
                  const SizedBox(height: 12),
                  TextField(controller: email, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email))),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: obscure,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock),
                      suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)),
                    ),
                  ),
                  if (errorMessage != null) ...[const SizedBox(height: 10), Align(alignment: Alignment.centerLeft, child: Text(errorMessage!, style: const TextStyle(color: Colors.red, fontSize: 12)))],
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.all(15)),
                      onPressed: () {
                        if (name.text.trim().isEmpty || email.text.trim().isEmpty || password.text.isEmpty) {
                          setState(() => errorMessage = 'Nama, email, dan password wajib diisi.');
                          return;
                        }
                        if (!email.text.contains('@') || !email.text.contains('.')) {
                          setState(() => errorMessage = 'Masukkan alamat email yang valid.');
                          return;
                        }
                        Navigator.pop(context, name.text.trim());
                      },
                      child: const Text('Login'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CartPage extends StatefulWidget {
  final List<CartLine> cart;
  final int total;
  final VoidCallback onCheckout;
  final VoidCallback onChanged;

  const CartPage({super.key, required this.cart, required this.total, required this.onCheckout, required this.onChanged});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  int get total => widget.cart.fold(0, (sum, e) => sum + e.item.price * e.qty);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(title: const Text('Keranjang')),
      body: widget.cart.isEmpty
          ? const Center(child: Text('Keranjang masih kosong.'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(18),
                    itemCount: widget.cart.length,
                    itemBuilder: (_, i) {
                      final line = widget.cart[i];
                      return Card(
                        child: ListTile(
                          leading: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.network(line.item.image, width: 60, height: 60, fit: BoxFit.cover),
                          ),
                          title: Text(line.item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text('Rp ${money(line.item.price)}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(onPressed: () => setState(() { if (line.qty > 1) line.qty--; else widget.cart.removeAt(i); widget.onChanged(); }), icon: const Icon(Icons.remove_circle_outline)),
                              Text('${line.qty}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              IconButton(onPressed: () => setState(() { line.qty++; widget.onChanged(); }), icon: const Icon(Icons.add_circle_outline)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Total'),
                            Text('Rp ${money(total)}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: orange)),
                          ],
                        ),
                      ),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: orange, padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14)),
                        onPressed: widget.onCheckout,
                        child: const Text('Pesan Sekarang'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
