# Warung CiTUT - Flutter App

Aplikasi mobile pemesanan makanan/minuman dengan tampilan oranye-krem seperti referensi.

## Fitur
- Beranda dengan header, pencarian, kategori, banner promo, dan menu populer.
- Daftar menu makanan/minuman.
- Pencarian menu.
- Detail menu.
- Keranjang + tambah/kurang jumlah.
- Checkout sederhana.
- Riwayat pesanan.
- Notifikasi.
- Login sederhana.
- Profil pengguna + logout.
- Bottom navigation.
- Responsive untuk layar HP.

## Menjalankan
1. Install Flutter dan Android Studio.
2. Buka folder ini di VS Code/Android Studio.
3. Jalankan:
   flutter pub get
   flutter run

## Membuat APK
flutter build apk --release

APK akan berada di:
build/app/outputs/flutter-apk/app-release.apk

Catatan:
Foto makanan memakai URL internet agar project tetap ringan. Saat aplikasi dipakai tanpa internet, gambar akan diganti dengan ikon makanan secara otomatis.
